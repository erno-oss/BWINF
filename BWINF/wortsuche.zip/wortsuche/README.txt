python wortsuche.py worte0.txt . --v --h

Die Umsetzung steht in form von Kommentaren in der Py-Datei.
